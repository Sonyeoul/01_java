package main.java.question.auth;

public interface SnsAuth {
    void login(String id,String pwd);
}
